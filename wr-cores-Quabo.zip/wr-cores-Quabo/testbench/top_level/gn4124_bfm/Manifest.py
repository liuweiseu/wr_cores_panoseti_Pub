files = ["mem_model.vhd", "textutil.vhd", "gn412x_bfm.vhd", "util.vhd"]


