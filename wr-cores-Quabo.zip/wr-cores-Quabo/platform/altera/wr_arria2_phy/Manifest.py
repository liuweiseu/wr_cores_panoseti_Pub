files = [
  "wr_arria2_phy.vhd",
  "wr_arria2_phy.qip",
  ];
