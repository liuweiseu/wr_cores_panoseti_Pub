files = ["pps_gen_wb.vhd",
				 "wr_pps_gen.vhd",
         "xwr_pps_gen.vhd"];
