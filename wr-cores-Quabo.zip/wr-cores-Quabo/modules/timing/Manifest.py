files = ["dmtd_phase_meas.vhd",
         "dmtd_with_deglitcher.vhd",
         "multi_dmtd_with_deglitcher.vhd",
         "hpll_period_detect.vhd",
         "pulse_gen.vhd",
         "pulse_stamper.vhd" ]
         
