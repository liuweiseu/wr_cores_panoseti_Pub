files = ["spll_period_detect.vhd",
#         "spll_bangbang_pd.vhd",
         "spll_wbgen2_pkg.vhd",
	 "spll_aligner.vhd",
         "wr_softpll_ng.vhd",
         "xwr_softpll_ng.vhd",
         "softpll_pkg.vhd",
         "spll_wb_slave.vhd"]
