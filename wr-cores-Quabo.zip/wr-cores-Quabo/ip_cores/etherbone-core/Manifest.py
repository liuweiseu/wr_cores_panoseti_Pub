modules = { "local": ["hdl/eb_master_core", "hdl/eb_slave_core", "hdl/eb_usb_core"] }
