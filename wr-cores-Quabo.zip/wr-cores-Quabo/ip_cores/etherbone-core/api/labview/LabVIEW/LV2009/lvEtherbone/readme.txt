Gettings started with the LabVIEW-Etherbone interface
=====================================================

- use LabVIEW and have a look at the "lvEtherbone.lvlib"
- open the VI-Tree "lvEtherbone.VI-Tree.vi"
- open and start a virtual Etherbone device by running the "application example snoop.vi"
- open and start "application_example_write (or read)" (by specifying the IP and port number)