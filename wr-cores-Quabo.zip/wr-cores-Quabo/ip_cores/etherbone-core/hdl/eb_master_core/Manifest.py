files = [
  "eb_framer.vhd",
  "eb_master_slave_wrapper.vhd",
  "eb_master_top.vhd",
  "eb_master_wb_if.vhd",
  "eb_record_gen.vhd",
  "eb_commit_len_fifo.vhd",
  "eb_master_eth_tx.vhd"
  ]
