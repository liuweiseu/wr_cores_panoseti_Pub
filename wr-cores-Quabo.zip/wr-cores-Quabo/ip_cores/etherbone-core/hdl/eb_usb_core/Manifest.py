files = [
  "ez_usb_pkg.vhd",
  "ez_usb.vhd",
  "ez_usb_fifos.vhd"
  ]
