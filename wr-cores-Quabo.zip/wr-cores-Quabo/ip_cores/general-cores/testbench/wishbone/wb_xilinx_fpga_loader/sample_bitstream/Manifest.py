target = "xilinx"
action = "synthesis"

files = "crc_gen.vhd"

syn_device = "xc6slx4"
syn_grade = "-2"
syn_package = "csg225"
syn_top = "crc_gen"
syn_project = "test.xise"
