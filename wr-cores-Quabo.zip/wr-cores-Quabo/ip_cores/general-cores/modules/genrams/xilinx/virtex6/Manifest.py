files =["v6_fifo_pkg.vhd",
        "v6_hwfifo_wrapper.vhd",
        "generic_async_fifo.vhd",
        "generic_sync_fifo.vhd"];
