files = ["generic_async_fifo.vhd",
         "generic_sync_fifo.vhd"]
