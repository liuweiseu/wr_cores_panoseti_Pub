files = [
"altera_async_fifo.vhd",
"generic_simple_dpram.vhd",
"generic_dpram.vhd",
"generic_spram.vhd",
"generic_dpram_mixed.vhd",
"altera_sync_fifo.vhd",
"gc_shiftreg.vhd"]
