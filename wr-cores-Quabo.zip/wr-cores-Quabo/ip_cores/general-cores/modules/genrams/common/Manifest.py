files = ["inferred_sync_fifo.vhd",
         "inferred_async_fifo.vhd",
         "generic_shiftreg_fifo.vhd"]
