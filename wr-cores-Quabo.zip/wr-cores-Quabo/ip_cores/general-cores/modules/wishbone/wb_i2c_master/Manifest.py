files= ["i2c_master_bit_ctrl.vhd",
"i2c_master_byte_ctrl.vhd",
"i2c_master_top.vhd",
"wb_i2c_master.vhd",
"xwb_i2c_master.vhd"];
