files = [
    "axi4_pkg.vhd",
    "wb_axi4lite_bridge.vhd",
    "xwb_axi4lite_bridge.vhd"
]
