files = ["wb_onewire_master.vhd",
				 "xwb_onewire_master.vhd",
				 "sockit_owm.v"];
