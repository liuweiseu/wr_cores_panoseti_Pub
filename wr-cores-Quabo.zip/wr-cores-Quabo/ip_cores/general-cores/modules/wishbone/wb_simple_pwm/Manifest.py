files = ["simple_pwm_wbgen2_pkg.vhd",
"simple_pwm_wb.vhd",
"wb_simple_pwm.vhd",
"xwb_simple_pwm.vhd"
];
