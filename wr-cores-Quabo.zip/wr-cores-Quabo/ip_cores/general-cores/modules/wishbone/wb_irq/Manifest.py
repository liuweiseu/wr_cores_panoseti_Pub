files = ["wb_irq_timer.vhd",
	 "irqm_core.vhd",
	 "wb_irq_lm32.vhd",
         "wb_irq_slave.vhd",
         "wb_irq_master.vhd",
         "wb_irq_pkg.vhd"]
