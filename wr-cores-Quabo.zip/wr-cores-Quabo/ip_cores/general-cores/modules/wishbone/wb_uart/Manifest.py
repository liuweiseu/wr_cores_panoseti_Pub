files = [	"uart_async_rx.vhd",
					"uart_async_tx.vhd",
					"uart_baud_gen.vhd",
					"simple_uart_wb.vhd",
					"simple_uart_pkg.vhd",
					"wb_simple_uart.vhd",
					"xwb_simple_uart.vhd"];
