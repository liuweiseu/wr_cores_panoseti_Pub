files = [ "spi_clgen.v",
 				  "spi_shift.v",
				  "spi_top.v",
				  "wb_spi.vhd",
				  "xwb_spi.vhd" ];

