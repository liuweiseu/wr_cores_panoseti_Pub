files = [ "wb_serial_lcd.vhd" ]
