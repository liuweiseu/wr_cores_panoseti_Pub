files = [ "xwb_dma.vhd", "xwb_streamer.vhd" ];
