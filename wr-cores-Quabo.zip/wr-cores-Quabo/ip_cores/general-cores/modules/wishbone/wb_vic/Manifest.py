files = ["vic_prio_enc.vhd",
         "wb_slave_vic.vhd",
         "wb_vic.vhd",
         "xwb_vic.vhd"]
