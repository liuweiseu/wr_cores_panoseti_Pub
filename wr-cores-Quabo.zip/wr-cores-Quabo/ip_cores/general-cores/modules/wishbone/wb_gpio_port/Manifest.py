files = ["wb_gpio_port.vhd",
			   "xwb_gpio_port.vhd"];