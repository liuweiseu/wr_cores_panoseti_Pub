files = [ 
  "altera_spi.vhd",
  "flash_top.vhd",
  "altera_flash_pkg.vhd",
  ]
