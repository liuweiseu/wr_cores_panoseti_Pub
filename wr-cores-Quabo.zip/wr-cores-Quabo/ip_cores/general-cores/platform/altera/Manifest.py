modules = { "local" : [
  "wb_pcie",
  "flash",
  "networks",
  ]}
