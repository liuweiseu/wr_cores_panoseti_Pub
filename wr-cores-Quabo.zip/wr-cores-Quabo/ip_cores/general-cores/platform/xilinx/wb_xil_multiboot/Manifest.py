files = [
      "spi_master.vhd",
      "multiboot_fsm.vhd",
      "multiboot_regs.vhd",
      "xwb_xil_multiboot.vhd"
    ]
