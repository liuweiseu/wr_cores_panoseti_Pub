files = [ "vme64x_core.vhd",
          "vme64x_pkg.vhd",
          "vme_bus.vhd",
          "vme_cr_csr_space.vhd",
          "vme_funct_match.vhd",
          "vme_irq_controller.vhd",
          "vme_user_csr.vhd",
          "xvme64x_core.vhd"]
