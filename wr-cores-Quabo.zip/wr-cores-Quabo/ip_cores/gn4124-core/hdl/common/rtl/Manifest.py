files = ["dummy_ctrl_regs.vhd",
         "dummy_stat_regs.vhd",
         "wb_addr_decoder.vhd"]
