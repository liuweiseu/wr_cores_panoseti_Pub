files = [
    "wr_clbv2_pkg.vhd",
    "xwrc_board_clbv2.vhd",
    "wrc_board_clbv2.vhd",
]

modules = {
    "local" : [
        "../common",
    ]
}
