files = [
    "wr_spec_pkg.vhd",
    "xwrc_board_spec.vhd",
    "wrc_board_spec.vhd",
]

modules = {
    "local" : [
        "../common",
    ]
}
