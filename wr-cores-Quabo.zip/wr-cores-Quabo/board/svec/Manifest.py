files = [
    "wr_svec_pkg.vhd",
    "xwrc_board_svec.vhd",
    "wrc_board_svec.vhd",
]

modules = {
    "local" : [
        "../common",
    ]
}
