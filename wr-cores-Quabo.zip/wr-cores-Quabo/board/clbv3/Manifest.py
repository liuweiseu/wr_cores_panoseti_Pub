files = [
    "wr_clbv3_pkg.vhd",
    "xwrc_board_clbv3.vhd",
    "wrc_board_clbv3.vhd",
]

modules = {
    "local" : [
        "../common",
    ]
}
