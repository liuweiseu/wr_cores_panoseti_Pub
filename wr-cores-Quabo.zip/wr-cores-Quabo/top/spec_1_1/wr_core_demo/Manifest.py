files = ["spec_top.vhd", "spec_top.ucf", "spec_reset_gen.vhd"]

modules = { "local" : ["../../../"] }
